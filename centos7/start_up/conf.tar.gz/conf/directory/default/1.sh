for i in `seq 6031 6033`; do sed -e "s/1000/$i/" 1000.xml > $i.xml ; done
