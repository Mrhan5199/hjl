for i in `seq --format=%1.f 28830938  28830950`; do sed -e "s/28830287/$i/" 28830287.xml > $i.xml ; done

