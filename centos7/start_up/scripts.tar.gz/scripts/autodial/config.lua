--autodial config
--webservice url
Autodial_WebServiceURL = "http://127.0.0.1/zswitchcrm101/webservices/autodialPS.php"; 
Autodial_sipif = "special";
Autodial_ctx = "special_ctx";




