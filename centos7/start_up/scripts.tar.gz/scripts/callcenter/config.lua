--callcenter config
--webservice url
WebServiceURL = "http://172.168.20.253:8086/zsitsms/webservices/callcenter.php"; 
--agent register sip interface
AgentSipIf = "sofia/internal";
--extent agent sip interface

-- enable record
EnableRecord = true;
-- enable report  number
PlayWorkNumber = true;
--record path
RecoardPath = "/recordings/";


