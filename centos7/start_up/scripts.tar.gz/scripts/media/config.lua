MEDIA_CFG={
	record_dir = "/usr/local/freeswitch/recordings/",
}