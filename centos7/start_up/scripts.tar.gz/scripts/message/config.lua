
MESSAGE_CONFIG = {
	notify = {
		{app="",uri}
	},	
	
};