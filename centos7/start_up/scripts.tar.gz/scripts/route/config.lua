ROUTE_CONFIG = {
--Check blocklist URL	
checkBlocklistURL = 'http://127.0.0.1/zsitsms121/webservices/checkBlocklist.php',
--ivr callout context
IVRaCtx = 'internal_ctx',
-- ivr context
IVRbCtx = 'ivrcallout',
-- ivr caller number
IVRCaller = '9999',
-- ivr call timeout
IVRTimeout = 30,

}