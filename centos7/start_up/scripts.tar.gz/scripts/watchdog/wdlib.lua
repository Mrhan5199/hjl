--wdlib.lua
--线程监控函数库


