#!/usr/bin/expect -f
set timeout -1
set username 849272199@qq.com
set password han849272199
spawn git clone https://code.cdqidian.net/tangdy/zsitsms.git /var/www/html/zsitsms
expect "Username"
send "$username\n"
expect "Password"
send "$password\n"
expect eof
